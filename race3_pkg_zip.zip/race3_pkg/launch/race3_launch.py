from launch_ros.actions import Node
from launch import LaunchDescription

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='race3_pkg',
            executable='pure_pursuit_node',
            name='pure_pursuit_node',
            parameters=[
                {'speed': 1.0},
                {'kp':0.3},
                {'cornerKpCoeff': 2.0},
                {'lookAheadDistance': 2.0},
                # {'waypoints_file': "/home/student/sim_ws/src/race_2_rrt/optimized_pts_1.csv"}
                {'waypoints_file': "/home/student/sim_ws/src/race3_pkg/data/race3_waypoints.csv"}
            ]
        ),
    ])

